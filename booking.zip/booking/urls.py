from django.urls import path
from . import views

urlpatterns = [
    # URLs cho người dùng thông thường
    path('', views.booking_page, name='booking_page'),
    path('create_booking/', views.create_booking, name='create_booking'),
    path('my-bookings/', views.my_bookings, name='my_bookings'),
    path('cancel-booking/', views.cancel_booking, name='cancel_booking'),

    # --- URLs cho Admin Dashboard ---
    # Trang chính
    path('dashboard/', views.admin_dashboard, name='admin_dashboard'),
    
    # Quản lý phòng học
    path('dashboard/rooms/', views.manage_rooms, name='manage_rooms'),
    path('dashboard/rooms/add/', views.add_room, name='add_room'),
    path('dashboard/rooms/edit/<int:room_id>/', views.edit_room, name='edit_room'),
    path('dashboard/rooms/delete/<int:room_id>/', views.delete_room, name='delete_room'),
    path('dashboard/rooms/delete-all/', views.delete_all_rooms, name='delete_all_rooms'), # URL mới

    # Quản lý tài khoản
    path('dashboard/users/', views.manage_users, name='manage_users'),
    path('dashboard/users/add/', views.add_user, name='add_user'),
    path('dashboard/users/edit/<int:user_id>/', views.edit_user, name='edit_user'),
    path('dashboard/users/delete/<int:user_id>/', views.delete_user, name='delete_user'),
    path('dashboard/users/change-password/<int:user_id>/', views.change_user_password, name='change_user_password'),
    path('dashboard/users/delete-all/', views.delete_all_users, name='delete_all_users'), # URL mới

    # Quản lý lịch đăng ký (cho admin)
    path('dashboard/bookings/', views.manage_bookings, name='manage_bookings'),
    path('dashboard/bookings/cancel/<int:booking_id>/', views.admin_cancel_booking, name='admin_cancel_booking'),
    path('dashboard/bookings/delete-all/', views.delete_all_bookings, name='delete_all_bookings'), # URL mới
]

