from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required, user_passes_test
from django.views.decorators.http import require_POST
from django.contrib import messages
from django.db import IntegrityError, transaction
from django.db.models import Count, Q
from .models import Room, Booking
from django.contrib.auth.models import User
from .forms import CustomUserCreationForm, CustomUserChangeForm, RoomForm, AdminSetPasswordForm
from datetime import date, timedelta
from itertools import groupby

# --- Helpers & Regular Views ---

def is_admin(user):
    return user.is_superuser

SEMESTER_START_DATE = date(2025, 9, 8)

def get_valid_dates():
    # ... (Nội dung hàm này giữ nguyên) ...
    today = date.today()
    valid_dates_info = []
    for i in range(14):
        current_date = today + timedelta(days=i)
        if current_date.weekday() != 6:
            days_since_start = (current_date - SEMESTER_START_DATE).days
            week_number = (days_since_start // 7) + 1 if days_since_start >= 0 else 1
            valid_dates_info.append({'date': current_date, 'week': week_number})
    return valid_dates_info

@login_required
def booking_page(request):
    # ... (Nội dung hàm này giữ nguyên) ...
    valid_dates_info = get_valid_dates()
    
    selected_date_str = request.GET.get('selected_date')
    session = request.GET.get('session', 'sang')
    search_room = request.GET.get('search_room', '')
    search_periods_str = request.GET.getlist('search_periods')
    search_periods = [int(p) for p in search_periods_str if p.isdigit()]

    if selected_date_str:
        selected_date = date.fromisoformat(selected_date_str)
    else:
        selected_date = valid_dates_info[0]['date'] if valid_dates_info else date.today()

    if session == 'chieu':
        periods = range(6, 11)
    else:
        periods = range(1, 6)

    rooms_qs = Room.objects.all().order_by('name')
    if search_room:
        rooms_qs = rooms_qs.filter(name__icontains=search_room)

    if search_periods:
        booked_room_ids = Booking.objects.filter(
            date=selected_date,
            period__in=search_periods
        ).values_list('room_id', flat=True).distinct()
        rooms_qs = rooms_qs.exclude(id__in=booked_room_ids)

    bookings_on_date = Booking.objects.filter(date=selected_date).select_related('teacher')
    
    bookings_in_session = bookings_on_date.filter(period__in=periods)

    booking_map = {
        (b.room_id, b.period): b.teacher.get_full_name() or b.teacher.username 
        for b in bookings_in_session
    }

    grid = []
    for room in rooms_qs:
        row = {'room': room, 'period_data': []}
        for period in periods:
            teacher = booking_map.get((room.id, period))
            row['period_data'].append({'period': period, 'teacher': teacher})
        grid.append(row)

    all_rooms_count = Room.objects.count()
    total_bookings_in_session = bookings_in_session.count()
    user_bookings_in_session = bookings_in_session.filter(teacher=request.user).count()

    context = {
        'grid': grid,
        'periods': periods,
        'valid_dates_info': valid_dates_info,
        'selected_date': selected_date,
        'search_periods': search_periods,
        'search_room': search_room,
        'session': session,
        'rooms_count': all_rooms_count,
        'total_bookings_in_session': total_bookings_in_session,
        'user_bookings_in_session': user_bookings_in_session,
    }
    return render(request, 'booking/booking_page.html', context)


@login_required
@require_POST
def create_booking(request):
    # ... (Nội dung hàm này giữ nguyên) ...
    selected_date_str = request.POST.get('selected_date')
    room_id = request.POST.get('room_id')
    selected_periods = request.POST.getlist('periods')
    redirect_url = request.META.get('HTTP_REFERER', f'/?selected_date={selected_date_str}')

    if not all([selected_date_str, room_id, selected_periods]):
        messages.error(request, "Yêu cầu không hợp lệ. Vui lòng chọn ít nhất một tiết học.")
        return redirect(redirect_url)

    success_count = 0
    conflict_periods = []
    
    try:
        room = Room.objects.get(id=room_id)
        selected_date = date.fromisoformat(selected_date_str)
        
        with transaction.atomic():
            for period_str in selected_periods:
                period = int(period_str)
                if Booking.objects.filter(room=room, date=selected_date, period=period).exists():
                    session_display = 'chiều' if period > 5 else 'sáng'
                    period_display = period if period <= 5 else period - 5
                    conflict_periods.append(f"Tiết {period_display} ({session_display})")
                else:
                    Booking.objects.create(
                        teacher=request.user,
                        room=room,
                        date=selected_date,
                        period=period
                    )
                    success_count += 1
    except Room.DoesNotExist:
        messages.error(request, "Phòng học không tồn tại.")
    except Exception as e:
        messages.error(request, f"Đã xảy ra lỗi không mong muốn: {e}")

    if success_count > 0:
        messages.success(request, f"Đã đăng ký thành công {success_count} tiết tại phòng {room.name}.")
    if conflict_periods:
        messages.warning(request, f"Các tiết sau đã có người khác đăng ký: {', '.join(conflict_periods)}.")

    return redirect(f"{redirect_url}#room-{room_id}")


@login_required
def my_bookings(request):
    # ... (Nội dung hàm này giữ nguyên) ...
    today = date.today()
    user_bookings = Booking.objects.filter(teacher=request.user, date__gte=today).order_by('date', 'room__name', 'period')
    
    grouped_bookings = []

    def group_key(booking):
        session = "Sáng" if booking.period <= 5 else "Chiều"
        return (booking.date, booking.room, session)

    for key, group in groupby(user_bookings, key=group_key):
        date_obj, room_obj, session_name = key
        bookings_in_group = list(group)
        
        periods = [b.period for b in bookings_in_group]
        booking_ids = ",".join(str(b.id) for b in bookings_in_group)
        
        grouped_bookings.append({
            'date': date_obj,
            'room': room_obj,
            'session': session_name,
            'periods': periods,
            'booking_ids': booking_ids
        })

    context = {'grouped_bookings': grouped_bookings}
    return render(request, 'booking/my_bookings.html', context)


@login_required
@require_POST
def cancel_booking(request):
    # ... (Nội dung hàm này giữ nguyên) ...
    booking_ids_str = request.POST.get('booking_ids')
    if booking_ids_str:
        booking_ids = [int(id) for id in booking_ids_str.split(',')]
        bookings_to_delete = Booking.objects.filter(id__in=booking_ids, teacher=request.user)
        count = bookings_to_delete.count()
        if count > 0:
            bookings_to_delete.delete()
            messages.success(request, f"Đã hủy thành công {count} tiết học.")
        else:
            messages.error(request, "Không tìm thấy lịch đăng ký hoặc bạn không có quyền hủy.")
    else:
        messages.error(request, "Yêu cầu không hợp lệ.")
        
    return redirect('my_bookings')

# --- Admin Dashboard Views ---

@login_required
@user_passes_test(is_admin)
def admin_dashboard(request):
    # ... (Nội dung hàm này giữ nguyên) ...
    user_count = User.objects.count()
    room_count = Room.objects.count()
    today_booking_count = Booking.objects.filter(date=date.today()).count()
    total_booking_count = Booking.objects.count()
    recent_bookings = Booking.objects.order_by('-date', '-period')[:5]

    context = {
        'user_count': user_count,
        'room_count': room_count,
        'today_booking_count': today_booking_count,
        'total_booking_count': total_booking_count,
        'recent_bookings': recent_bookings,
    }
    return render(request, 'admin_dashboard/dashboard.html', context)

# --- Room Management ---
@login_required
@user_passes_test(is_admin)
def manage_rooms(request):
    query = request.GET.get('q', '')
    rooms = Room.objects.all()
    if query:
        rooms = rooms.filter(name__icontains=query)
    return render(request, 'admin_dashboard/manage_rooms.html', {'rooms': rooms.order_by('name'), 'query': query})

@login_required
@user_passes_test(is_admin)
@require_POST
def delete_all_rooms(request):
    Room.objects.all().delete()
    messages.success(request, "Đã xóa tất cả các phòng học.")
    return redirect('manage_rooms')


@login_required
@user_passes_test(is_admin)
def add_room(request):
    # ... (Nội dung hàm này giữ nguyên) ...
    if request.method == 'POST':
        form = RoomForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Đã thêm phòng học mới thành công.')
            return redirect('manage_rooms')
    else:
        form = RoomForm()
    return render(request, 'admin_dashboard/room_form.html', {'form': form, 'action': 'Thêm'})

@login_required
@user_passes_test(is_admin)
def edit_room(request, room_id):
    # ... (Nội dung hàm này giữ nguyên) ...
    room = get_object_or_404(Room, id=room_id)
    if request.method == 'POST':
        form = RoomForm(request.POST, instance=room)
        if form.is_valid():
            form.save()
            messages.success(request, 'Đã cập nhật thông tin phòng học.')
            return redirect('manage_rooms')
    else:
        form = RoomForm(instance=room)
    return render(request, 'admin_dashboard/room_form.html', {'form': form, 'action': 'Cập nhật'})

@login_required
@user_passes_test(is_admin)
@require_POST
def delete_room(request, room_id):
    # ... (Nội dung hàm này giữ nguyên) ...
    room = get_object_or_404(Room, id=room_id)
    room_name = room.name
    room.delete()
    messages.success(request, f"Đã xóa thành công phòng '{room_name}'.")
    return redirect('manage_rooms')

# --- User Management ---
@login_required
@user_passes_test(is_admin)
def manage_users(request):
    query = request.GET.get('q', '')
    users = User.objects.all()
    if query:
        users = users.filter(
            Q(username__icontains=query) |
            Q(first_name__icontains=query) |
            Q(last_name__icontains=query)
        )
    return render(request, 'admin_dashboard/manage_users.html', {'users': users.order_by('username'), 'query': query})

@login_required
@user_passes_test(is_admin)
@require_POST
def delete_all_users(request):
    User.objects.filter(is_superuser=False).delete()
    messages.success(request, "Đã xóa tất cả các tài khoản người dùng (trừ superuser).")
    return redirect('manage_users')

@login_required
@user_passes_test(is_admin)
def add_user(request):
    # ... (Nội dung hàm này giữ nguyên) ...
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Đã tạo tài khoản mới thành công.')
            return redirect('manage_users')
    else:
        form = CustomUserCreationForm()
    return render(request, 'admin_dashboard/user_form.html', {'form': form, 'action': 'Thêm'})

@login_required
@user_passes_test(is_admin)
def edit_user(request, user_id):
    # ... (Nội dung hàm này giữ nguyên) ...
    user = get_object_or_404(User, id=user_id)
    if request.method == 'POST':
        form = CustomUserChangeForm(request.POST, instance=user)
        if form.is_valid():
            form.save()
            messages.success(request, 'Đã cập nhật thông tin tài khoản.')
            return redirect('manage_users')
    else:
        form = CustomUserChangeForm(instance=user)
    return render(request, 'admin_dashboard/user_form.html', {'form': form, 'action': 'Cập nhật'})

@login_required
@user_passes_test(is_admin)
@require_POST
def delete_user(request, user_id):
    # ... (Nội dung hàm này giữ nguyên) ...
    user_to_delete = get_object_or_404(User, id=user_id)
    if user_to_delete.is_superuser:
        messages.error(request, "Không thể xóa tài khoản superuser.")
    else:
        username = user_to_delete.username
        user_to_delete.delete()
        messages.success(request, f"Đã xóa thành công người dùng '{username}'.")
    return redirect('manage_users')

@login_required
@user_passes_test(is_admin)
def change_user_password(request, user_id):
    # ... (Nội dung hàm này giữ nguyên) ...
    user_to_change = get_object_or_404(User, id=user_id)
    if request.method == 'POST':
        form = AdminSetPasswordForm(user_to_change, request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, f"Đã thay đổi mật khẩu cho người dùng '{user_to_change.username}' thành công.")
            return redirect('manage_users')
    else:
        form = AdminSetPasswordForm(user_to_change)
    return render(request, 'admin_dashboard/password_change_form.html', {'form': form, 'user_to_change': user_to_change})


# --- Booking Management (Admin) ---
@login_required
@user_passes_test(is_admin)
def manage_bookings(request):
    query = request.GET.get('q', '')
    bookings = Booking.objects.select_related('teacher', 'room').all()
    if query:
        bookings = bookings.filter(
            Q(teacher__username__icontains=query) |
            Q(teacher__first_name__icontains=query) |
            Q(teacher__last_name__icontains=query) |
            Q(room__name__icontains=query)
        )
    return render(request, 'admin_dashboard/manage_bookings.html', {'bookings': bookings.order_by('-date', '-period'), 'query': query})

@login_required
@user_passes_test(is_admin)
@require_POST
def delete_all_bookings(request):
    Booking.objects.all().delete()
    messages.success(request, "Đã xóa tất cả các lượt đăng ký.")
    return redirect('manage_bookings')

@login_required
@user_passes_test(is_admin)
@require_POST
def admin_cancel_booking(request, booking_id):
    # ... (Nội dung hàm này giữ nguyên) ...
    booking = get_object_or_404(Booking, id=booking_id)
    booking.delete()
    messages.success(request, "Đã xóa lượt đăng ký thành công.")
    return redirect('manage_bookings')

